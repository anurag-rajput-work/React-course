import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
        <div className="w-full h-screen duration-200 bg-black "> 

        

          <h1 className='bg-green-500 justify-center p-4 text-center
         m-4 hover:bg-pink-600 hover:text-xl duration-200' >hello world</h1>
          <button
            class="align-middle justify-center
        border border-green-600
        px-6 py-2 rounded-md
        text-green-600
        transition-all duration-300 ease-in-out
        hover:bg-green-600
        hover:text-white
        hover:translate-y-1
        hover:shadow-xl
        "
          >
        Hover Me
          </button>
        
      </div>    
    </>

  )
}

export default App
